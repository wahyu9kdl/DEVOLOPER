<template>
  <RouterView />
</template>

<script>
export default {

}
</script>
