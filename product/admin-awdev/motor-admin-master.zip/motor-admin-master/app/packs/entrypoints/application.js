import 'application/styles/bootstrap.scss'

import app from 'application'

document.addEventListener('DOMContentLoaded', () => {
  app.mount('#app')
})
