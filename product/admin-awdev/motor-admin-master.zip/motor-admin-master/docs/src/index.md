---
home: true
heroImage: https://user-images.githubusercontent.com/5418788/150341043-b82e41a8-42a4-467d-bac8-f1eefc9372be.png
tagline: Deploy a no-code admin panel for any application in less than a minute
actionText: Documentation →
actionLink: /guide/
---
