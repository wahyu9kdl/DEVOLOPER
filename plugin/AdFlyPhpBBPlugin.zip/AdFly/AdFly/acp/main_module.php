<?php
/**
 *
 * AdFly PhpBB Extension. An extension for the phpBB Forum Software package.
 *
 * @copyright (c) 2017, AdFly, https://adf.ly
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

namespace AdFly\AdFly\acp;

/**
 * AdFly PhpBB Extension ACP module.
 */
class main_module
{
	public $page_title;
	public $tpl_name;
	public $u_action;

	public function main($id, $mode)
	{
		global $config, $request, $template, $user;

		$user->add_lang_ext('AdFly/AdFly', 'common');
		$this->tpl_name = 'acp_adfly_extension_body';
		$this->page_title = $user->lang('ACP_ADFLY_EXTENSION_TITLE');
		add_form_key('adfly/adfly');

		$assign_vars = array(
			'U_ACTION'							=> $this->u_action,
			'adfly_extension_user_id'			=> trim($config['adfly_extension_user_id']) ?: '0',
			'adfly_extension_ad_type'			=> trim($config['adfly_extension_ad_type']) ?: 'int',
			'adfly_extension_domain'			=> trim($config['adfly_extension_domain']) ?: 'adf.ly',
			'adfly_extension_custom_domain'		=> trim($config['adfly_extension_custom_domain']) ?: '',
			'adfly_extension_include_exclude'	=> trim($config['adfly_extension_include_exclude']) ?: 'include',
			'adfly_extension_domains'			=> trim($config['adfly_extension_domains']) ?: 'example.com,google.com',
			'adfly_extension_protocol'			=> trim($config['adfly_extension_protocol']) ?: 'http',
			'adfly_extension_popads_enabled'	=> trim($config['adfly_extension_popads_enabled']) ?: '0',
			'adfly_extension_entry_enabled'		=> trim($config['adfly_extension_entry_enabled']) ?: '0',
			'adfly_extension_nofollow_enabled'	=> trim($config['adfly_extension_nofollow_enabled']) ?: '0'
		);
		$errors = array();

		if ($request->is_set_post('submit'))
		{
			if (!check_form_key('adfly/adfly'))
			{
				trigger_error('FORM_INVALID', E_USER_WARNING);
			}

			$assign_vars['adfly_extension_user_id'] = $this->user_id_validate(trim($request->variable('adfly_extension_user_id', '0')), $errors);
			$assign_vars['adfly_extension_ad_type'] = $this->array_element_validate(trim($request->variable('adfly_extension_ad_type', 'int')), array('int', 'banner'), $errors);
			$assign_vars['adfly_extension_domain'] = $this->array_element_validate(trim($request->variable('adfly_extension_domain', 'adf.ly')), array('adf.ly', 'j.gs', 'q.gs'), $errors);
			$assign_vars['adfly_extension_custom_domain'] = $this->custom_domain_validate(trim($request->variable('adfly_extension_custom_domain', '')), $errors);
			$assign_vars['adfly_extension_include_exclude'] = $this->array_element_validate(trim($request->variable('adfly_extension_include_exclude', 'include')), array('include', 'exclude'), $errors);
			$assign_vars['adfly_extension_domains'] = $this->include_exclude_domains_value_validate(trim($request->variable('adfly_extension_domains', 'example.com,google.com')), $errors);
			$assign_vars['adfly_extension_protocol'] = $this->array_element_validate(trim($request->variable('adfly_extension_protocol', 'http')), array('http', 'https'), $errors);
			$assign_vars['adfly_extension_popads_enabled'] = $this->array_element_validate(trim($request->variable('adfly_extension_popads_enabled', '0')), array('1', '0'), $errors);
			$assign_vars['adfly_extension_entry_enabled'] = $this->array_element_validate(trim($request->variable('adfly_extension_entry_enabled', '0')), array('1', '0'), $errors);
			$assign_vars['adfly_extension_nofollow_enabled'] = $this->array_element_validate(trim($request->variable('adfly_extension_nofollow_enabled', '0')), array('1', '0'), $errors);

			if (count($errors)) {
				foreach ($errors as $error) {
					$template->assign_block_vars('errors', array('error' => $error));
				}
			} else {
				foreach ($assign_vars as $k => $v) {
					if (strpos($k, 'adfly_extension_') === 0) {
						$config->set($k, $v);
					}
				}

				trigger_error($user->lang('ACP_DEMO_SETTING_SAVED') . adm_back_link($this->u_action));
			}
		}

		$template->assign_vars($assign_vars);
	}

	private function array_element_validate($value, array $arr, array &$errors) {
		if (!in_array($value, $arr)) {
			$errors []= "{$value} should be equal to one of this values: " . implode(', ', $arr) . '.';
		}
		return $value;
	}

	private function user_id_validate($value, array &$errors) {
		if (!preg_match("/^([0-9])+$/i", $value = str_replace(" ", "", trim($value))) || intval($value) < 1) {
			$errors []= 'User ID is required and must be a number.';
		}
		return $value;
	}

	private function domain_name_validate($value, array &$errors) {
		if (!preg_match('/^(?!\-)(?:[a-zA-Z\d\-]{0,62}[a-zA-Z\d]\.){1,126}(?!\d+)[a-zA-Z\d]{1,63}$/', $value)) {
			$errors []= "{$value} is not valid domain name.";
		}
		return $value;
	}

	private function include_exclude_domains_value_validate($value, array &$errors) {
		$arr = array_filter(array_map(function($x) { return trim($x); }, explode(',', trim($value))), function($x) { return $x ? true : false; });
		if (count($arr)) {
			$self = $this;
			array_map(function($x) use(&$errors, $self) {
				$self->domain_name_validate($x, $errors);
			}, $arr);
		} else {
			$errors []= 'You must specify at least one domain name to include/exclude.';
		}

		return implode(',', $arr);
	}

	private function custom_domain_validate($value, array &$errors) {
		if ($value = trim($value)) {
			$this->domain_name_validate($value, $errors);
		}

		return $value;
	}
}
