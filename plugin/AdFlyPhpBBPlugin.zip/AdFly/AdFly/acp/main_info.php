<?php
/**
 *
 * AdFly PhpBB Extension. An extension for the phpBB Forum Software package.
 *
 * @copyright (c) 2017, AdFly, https://adf.ly
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

namespace AdFly\AdFly\acp;

/**
 * AdFly PhpBB Extension ACP module info.
 */
class main_info
{
	public function module()
	{
		return array(
			'filename'	=> '\AdFly\AdFly\acp\main_module',
			'title'		=> 'ACP_ADFLY_EXTENSION_TITLE',
			'modes'		=> array(
				'settings'	=> array(
					'title'	=> 'ACP_ADFLY_EXTENSION_TITLE',
					'auth'	=> 'ext_AdFly/AdFly && acl_a_board',
					'cat'	=> array('ACP_ADFLY_EXTENSION_TITLE')
				),
			),
		);
	}
}
