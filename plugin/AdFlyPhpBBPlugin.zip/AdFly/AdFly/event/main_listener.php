<?php
/**
 *
 * AdFly PhpBB Extension. An extension for the phpBB Forum Software package.
 *
 * @copyright (c) 2017, AdFly, https://adf.ly
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

namespace AdFly\AdFly\event;

/**
 * @ignore
 */
use Symfony\Component\EventDispatcher\EventSubscriberInterface;

/**
 * AdFly PhpBB Extension Event listener.
 */
class main_listener implements EventSubscriberInterface
{
	static public function getSubscribedEvents()
	{
		return array(
			'core.display_forums_modify_template_vars'	=> 'display_forums_modify_template_vars',
			'core.user_setup'				=> 'load_language_on_setup',
			'core.page_header'				=> 'add_page_header_link',
			'core.viewonline_overwrite_location'	=> 'viewonline_page',
		);
	}

	/* @var \phpbb\controller\helper */
	protected $helper;

	/* @var \phpbb\template\template */
	protected $template;

	/* @var \phpbb\user */
	protected $user;

	/** @var string phpEx */
	protected $php_ext;

	/**
	 * Constructor
	 *
	 * @param \phpbb\controller\helper	$helper		Controller helper object
	 * @param \phpbb\template\template	$template	Template object
	 * @param \phpbb\user               $user       User object
	 * @param string                    $php_ext    phpEx
	 */
	public function __construct(\phpbb\controller\helper $helper, \phpbb\template\template $template, \phpbb\user $user, $php_ext)
	{
		$this->helper   = $helper;
		$this->template = $template;
		$this->user     = $user;
		$this->php_ext  = $php_ext;
	}

	/**
	 * Load common language files during user setup
	 *
	 * @param \phpbb\event\data	$event	Event object
	 */
	public function load_language_on_setup($event)
	{
		$lang_set_ext = $event['lang_set_ext'];
		$lang_set_ext[] = array(
			'ext_name' => 'AdFly/AdFly',
			'lang_set' => 'common',
		);
		$event['lang_set_ext'] = $lang_set_ext;
	}

	/**
	 * Add a link to the controller in the forum navbar
	 */
	public function add_page_header_link()
	{
		/*$this->template->assign_vars(array(
			'U_DEMO_PAGE'	=> $this->helper->route('AdFly_AdFly_controller', array('name' => 'world')),
		));*/

		global $config;
		$assign_vars = array(
			'adfly_extension_user_id'			=> trim($config['adfly_extension_user_id']) ?: '0',
			'adfly_extension_ad_type'			=> trim($config['adfly_extension_ad_type']) ?: 'int',
			'adfly_extension_domain'			=> trim($config['adfly_extension_domain']) ?: 'adf.ly',
			'adfly_extension_custom_domain'		=> trim($config['adfly_extension_custom_domain']) ?: '',
			'adfly_extension_protocol'			=> trim($config['adfly_extension_protocol']) ?: 'http',
			'adfly_extension_popads_enabled'	=> trim($config['adfly_extension_popads_enabled']) ?: '0',
			'adfly_extension_entry_enabled'		=> trim($config['adfly_extension_entry_enabled']) ?: '0',
			'adfly_extension_nofollow_enabled'	=> trim($config['adfly_extension_nofollow_enabled']) ?: '0',
			'adfly_extension_domains_array'		=> $this->gen_include_exclude_domains_script(
				trim($config['adfly_extension_domains']) ?: 'example.com,google.com',
				trim($config['adfly_extension_include_exclude']) ?: 'include'
			)
		);
		$this->template->assign_vars($assign_vars);
	}

	private function gen_include_exclude_domains_script($value, $type) {
		$script = 'var ';
		if ($type == 'include') {
			$script .= 'domains = [';
		} else {
			$script .= 'exclude_domains = [';
		}
		if ($domains = trim($value)) {
			$script .= implode(', ', array_map(function($x) {
				return json_encode(trim($x));
			}, explode(',', trim($domains))));
		}

		$script .= '];';
		return $script;
	}

	/**
	 * Show users viewing Acme Demo on the Who Is Online page
	 *
	 * @param \phpbb\event\data	$event	Event object
	 */
	public function viewonline_page($event)
	{
		/*if ($event['on_page'][1] === 'app' && strrpos($event['row']['session_page'], 'app.' . $this->php_ext . '/demo') === 0)
		{
			$event['location'] = $this->user->lang('VIEWING_ACME_DEMO');
			$event['location_url'] = $this->helper->route('AdFly_AdFly_controller', array('name' => 'world'));
		}*/
	}

	/**
	 * A sample PHP event
	 * Modifies the names of the forums on index
	 *
	 * @param \phpbb\event\data	$event	Event object
	 */
	public function display_forums_modify_template_vars($event)
	{
		/*$forum_row = $event['forum_row'];
		$forum_row['FORUM_NAME'] .= ' :: Acme Event ::';
		$event['forum_row'] = $forum_row;*/
	}
}
