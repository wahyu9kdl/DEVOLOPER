# AdFly PhpBB Extension

## Installation

Copy the extension to phpBB/ext/AdFly/AdFly

Go to "ACP" > "Customise" > "Extensions" and enable the "AdFly PhpBB Extension" extension.

## License

[GPLv2](license.txt)
